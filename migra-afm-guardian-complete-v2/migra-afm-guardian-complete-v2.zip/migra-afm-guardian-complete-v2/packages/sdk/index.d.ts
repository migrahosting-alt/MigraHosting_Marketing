export function init(opts: any): void;
