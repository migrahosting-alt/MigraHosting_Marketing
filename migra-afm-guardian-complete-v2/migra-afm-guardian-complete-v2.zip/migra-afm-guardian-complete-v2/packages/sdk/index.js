export function init(opts){ console.log('[AFM SDK] init', opts); }
