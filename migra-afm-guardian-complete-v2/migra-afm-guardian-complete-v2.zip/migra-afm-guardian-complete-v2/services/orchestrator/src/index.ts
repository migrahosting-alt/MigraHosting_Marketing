import express from "express";
import morgan from "morgan";
import cors from "cors";
import dotenv from "dotenv";
import fetch from "node-fetch";
import { z } from "zod";
import { decideToolWithLLM, DecidedTool } from "./llmRouter";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(morgan("dev"));

const ADAPTERS_URL = process.env.ADAPTERS_URL || "http://adapters:8095";

const Actor = z.object({
  userId: z.string(),
  roles: z.array(z.string()).default([]),
  scopes: z.array(z.string()).default([]),
});

const ToolCallSchema = z.object({
  name: z.string(),
  input: z.record(z.any()).default({}),
  actor: Actor.optional(),
});

const ChatMessageSchema = z.object({
  from: z.enum(["user", "afm"]),
  text: z.string(),
});

const ChatRequestSchema = z.object({
  message: z.string().optional(),
  toolCall: ToolCallSchema.optional(),
  history: z.array(ChatMessageSchema).optional(),
  actor: Actor.optional(),
});

type ToolHandlerCtx = { actor: z.infer<typeof Actor> | undefined };
type ToolHandler = (input: any, ctx: ToolHandlerCtx) => Promise<any>;

type Tool = {
  name: string;
  schema: z.ZodTypeAny;
  handler: ToolHandler;
};

const registry = new Map<string, Tool>();

function registerTool(tool: Tool) {
  registry.set(tool.name, tool);
}

registerTool({
  name: "dns_list_records",
  schema: z.object({ zone: z.string().min(1) }),
  handler: async (input, ctx) => {
    const r = await fetch(
      `${ADAPTERS_URL}/dns/${encodeURIComponent(input.zone)}/records`
    );
    return r.json();
  },
});

registerTool({
  name: "user_get_summary",
  schema: z.object({ query: z.string().min(1) }),
  handler: async (input, ctx) => {
    const r = await fetch(
      `${ADAPTERS_URL}/user/summary?q=${encodeURIComponent(input.query)}`
    );
    return r.json();
  },
});

registerTool({
  name: "backups_list",
  schema: z.object({ domain: z.string().min(1) }),
  handler: async (input, ctx) => {
    const r = await fetch(
      `${ADAPTERS_URL}/backups/${encodeURIComponent(input.domain)}`
    );
    return r.json();
  },
});

function renderReply(call: any, result: any): string {
  if (call.name === "dns_list_records" && result?.records) {
    const rows = result.records.map((r: any) => `${r.name}  ${r.type}  ${r.value}`).join("\n");
    return `I found ${result.records.length} DNS records for ${result.zone}:
` + rows;
  }
  if (call.name === "user_get_summary" && result?.user) {
    const u = result.user;
    return [
      `Here’s what I see for ${u.email}:`,
      `Plans: ${(u.plans || []).join(", ") || "none"}`,
      `Invoices: ${u.invoices}`,
      `Open tickets: ${u.tickets}`,
    ].join("\n");
  }
  if (call.name === "backups_list" && result?.backups) {
    const rows = result.backups.map((b: any) => `• ${b.file}`).join("\n");
    return `Here are the latest backups for ${result.domain}:
` + rows;
  }
  return "OK, I executed the tool.";
}

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "orchestrator", env: process.env.NODE_ENV || "dev" });
});

app.post("/chat", async (req, res) => {
  try {
    const payload = ChatRequestSchema.parse(req.body);
    const actor = payload.actor;

    if (payload.toolCall) {
      const call = ToolCallSchema.parse(payload.toolCall);
      const tool = registry.get(call.name);
      if (!tool) return res.status(400).json({ ok: false, error: "unknown_tool" });

      const validated = tool.schema.parse(call.input);
      const result = await tool.handler(validated, { actor });
      const reply = renderReply(call, result);

      return res.json({
        ok: true,
        mode: "tool_direct",
        reply,
        toolCall: { ...call, input: validated },
        toolResult: result,
      });
    }

    if (payload.message) {
      const history = payload.history || [];
      const decision: DecidedTool = await decideToolWithLLM(
        payload.message,
        history as any
      );
      if (!decision) {
        return res.json({
          ok: true,
          mode: "chat_only",
          reply:
            "Mwen la pou tcheke DNS, backup, ak rezime kliyan. Egzanp: “Check DNS pou migrahosting.com.”",
        });
      }
      const tool = registry.get(decision.name);
      if (!tool) return res.status(400).json({ ok: false, error: "unknown_tool" });

      const validated = tool.schema.parse(decision.input);
      const result = await tool.handler(validated, { actor });
      const reply = renderReply({ name: decision.name }, result);

      return res.json({
        ok: true,
        mode: "tool_auto",
        reply,
        decidedTool: {
          name: decision.name,
          input: validated,
        },
        toolResult: result,
      });
    }

    return res.status(400).json({ ok: false, error: "empty_request" });
  } catch (e: any) {
    console.error("[orchestrator] error:", e);
    res.status(400).json({ ok: false, error: e?.message || "bad_request" });
  }
});

const port = process.env.PORT || 8090;
app.listen(port, () => {
  console.log(`[AFM] orchestrator listening on :${port}`);
});
