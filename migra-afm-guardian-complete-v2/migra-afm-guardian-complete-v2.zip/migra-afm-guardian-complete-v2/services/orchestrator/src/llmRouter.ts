import fetch from "node-fetch";
import { z } from "zod";

const LlmDecisionSchema = z.object({
  tool: z.union([
    z.literal("dns_list_records"),
    z.literal("user_get_summary"),
    z.literal("backups_list"),
    z.null()
  ]).optional(),
  input: z.record(z.any()).optional()
});

export type DecidedTool = {
  name: "dns_list_records" | "user_get_summary" | "backups_list";
  input: any;
} | null;

const DEFAULT_MODEL = process.env.LLM_MODEL || "gpt-4.1-mini";
const API_URL = process.env.LLM_API_URL || "https://api.openai.com/v1/chat/completions";
const API_KEY = process.env.LLM_API_KEY || "";

function heuristicDecision(message: string): DecidedTool {
  const m = message.toLowerCase();
  if (m.includes("dns") || m.includes("record") || m.includes("mx") || m.includes("spf")) {
    const domain = m.match(/[a-z0-9.-]+\.[a-z]{2,}/)?.[0] || "example.com";
    return { name: "dns_list_records", input: { zone: domain } };
  }
  if (m.includes("backup")) {
    const domain = m.match(/[a-z0-9.-]+\.[a-z]{2,}/)?.[0] || "example.com";
    return { name: "backups_list", input: { domain } };
  }
  if (m.includes("client") || m.includes("user") || m.includes("account")) {
    const email = m.match(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/)?.[0] || "client@example.com";
    return { name: "user_get_summary", input: { query: email } };
  }
  return null;
}

type HistoryMessage = { from: "user" | "afm"; text: string };

export async function decideToolWithLLM(
  message: string,
  history: HistoryMessage[] | undefined
): Promise<DecidedTool> {
  if (!API_KEY) {
    return heuristicDecision(message);
  }

  const systemPrompt = `
You are Abigail, the AI brain of Migra AFM Guardian.
Decide exactly one tool to call, or null.

Tools:
- "dns_list_records" with { "zone": "<domain>" }
- "user_get_summary" with { "query": "<email or search text>" }
- "backups_list" with { "domain": "<domain>" }

Output ONLY JSON like:
{"tool":"dns_list_records","input":{"zone":"migrahosting.com"}}
or
{"tool":null,"input":{}}
`;

  const userContent = JSON.stringify({
    message,
    history: (history || []).slice(-10),
  });

  const body = {
    model: DEFAULT_MODEL,
    messages: [
      { role: "system", content: systemPrompt.trim() },
      { role: "user", content: userContent },
    ],
    temperature: 0.1,
    max_tokens: 150,
  };

  try {
    const r = await fetch(API_URL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${API_KEY}`,
      },
      body: JSON.stringify(body),
    });
    if (!r.ok) {
      console.error("[llmRouter] HTTP", r.status, await r.text());
      return heuristicDecision(message);
    }
    const data: any = await r.json();
    const raw = data?.choices?.[0]?.message?.content?.trim();
    if (!raw) return heuristicDecision(message);

    let parsed: any;
    try { parsed = JSON.parse(raw); }
    catch {
      console.error("[llmRouter] JSON parse failed:", raw);
      return heuristicDecision(message);
    }

    const decision = LlmDecisionSchema.parse(parsed);
    if (!decision.tool || decision.tool === null) return null;
    return { name: decision.tool, input: decision.input || {} };
  } catch (e: any) {
    console.error("[llmRouter] error:", e);
    return heuristicDecision(message);
  }
}
