import express from "express";
import morgan from "morgan";
import cors from "cors";
import dotenv from "dotenv";
import fetch from "node-fetch";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(morgan("dev"));

const ORCH_URL = process.env.ORCH_URL || "http://orchestrator:8090";

async function requireAuth(req: any, res: any, next: any) {
  const auth = String(req.headers.authorization || "");
  if (!auth.startsWith("Bearer ")) {
    return res.status(401).json({ ok: false, error: "missing_bearer" });
  }
  (req as any).actor = {
    userId: "demo",
    roles: ["support"],
    scopes: ["support.read"],
  };
  next();
}

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "gateway", env: process.env.NODE_ENV || "dev" });
});

app.post("/chat", requireAuth, async (req, res) => {
  try {
    const actor = (req as any).actor;
    const body = {
      ...req.body,
      actor,
    };
    const r = await fetch(ORCH_URL + "/chat", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: String(req.headers.authorization || ""),
      },
      body: JSON.stringify(body),
    });
    const data = await r.json();
    res.status(r.status).json(data);
  } catch (e: any) {
    console.error("[gateway] error:", e);
    res.status(502).json({ ok: false, error: "bad_gateway", detail: e?.message });
  }
});

const port = process.env.PORT || 8080;
app.listen(port, () => {
  console.log(`[AFM] gateway listening on :${port}`);
});
