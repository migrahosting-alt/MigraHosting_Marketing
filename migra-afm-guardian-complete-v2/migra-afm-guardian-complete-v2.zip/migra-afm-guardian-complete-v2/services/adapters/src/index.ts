import express from "express";
import morgan from "morgan";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(morgan("dev"));

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "adapters", env: process.env.NODE_ENV || "dev" });
});

app.get("/dns/:zone/records", (req, res) => {
  const zone = req.params.zone;
  res.json({
    ok: true,
    zone,
    records: [
      { name: "cp", type: "A", value: "31.220.98.95", ttl: 300 },
      { name: "mail", type: "A", value: "154.38.180.61", ttl: 300 },
      { name: "@", type: "MX", value: "mail.migrahosting.com", ttl: 300 },
    ],
  });
});

app.get("/user/summary", (req, res) => {
  const q = String(req.query.q || "");
  res.json({
    ok: true,
    query: q,
    user: {
      email: q || "client@example.com",
      plans: ["Web Hosting Premium"],
      invoices: 5,
      tickets: 1,
    },
  });
});

app.get("/backups/:domain", (req, res) => {
  const domain = req.params.domain;
  res.json({
    ok: true,
    domain,
    backups: [
      { file: `/srv1/clients/${domain}/2025-11-10.tar.gz`, size_mb: 512 },
      { file: `/srv1/clients/${domain}/2025-11-09.tar.gz`, size_mb: 490 },
    ],
  });
});

const port = process.env.PORT || 8095;
app.listen(port, () => {
  console.log(`[AFM] adapters listening on :${port}`);
});
